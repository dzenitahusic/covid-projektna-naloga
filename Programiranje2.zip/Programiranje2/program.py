import json
from urllib.request import urlopen
# url = "https://opendata.ecdc.europa.eu/covid19/nationalcasedeath_eueea_daily_ei/json/"
# response = urlopen(url)
# data_json = json.loads(response.read())
# with open('C:\\Users\\Admin\\Documents\\Pro\\data.json', 'w') as f:
#     json.dump(data_json, f)

f = open('C:\\Users\\Lenovo\\Downloads\\Programiranje2\\data.json', 'r')
data = json.load(f)
podatki = data["records"]

import numpy as np
import matplotlib.pyplot as plt

#slovar vseh smrtni glede na drzavo
sl_drzave_smrt = {}
for el in podatki:
    if el["countriesAndTerritories"] in sl_drzave_smrt.keys():
        if el["deaths"] != None:
            sl_drzave_smrt[el["countriesAndTerritories"]] += el["deaths"]
    else:
        if el["deaths"] != None:
            sl_drzave_smrt[el["countriesAndTerritories"]] = el["deaths"]
                       
#urejen list smrtni od največ do najmanj po državah
list_drzave_smrt = list(sl_drzave_smrt.items())

#povprečno število smrti na dan v državi
povprecje_drzav = list()
for drzava in sl_drzave_smrt:
    smrti = sl_drzave_smrt[drzava]
    dni = 0
    for el in podatki:
        if drzava == el["countriesAndTerritories"]:
            dni += 1
    povprecje_drzav.append((drzava, int(smrti/dni)))
    
#slovar vseh smrti po letih
sl_leto_smrt = {}
for el in podatki:
    if el["year"] in sl_leto_smrt.keys():
        if el["deaths"] != None:
            sl_leto_smrt[el["year"]] += el["deaths"]
    else:
        if el["deaths"] != None:
            sl_leto_smrt[el["year"]] = el["deaths"]

#urejen list smrti od največ do najmanj po letih
list_leto_smrt = list(sl_leto_smrt.items())
            
#vse smrti
vse_smrti = sum(sl_leto_smrt.values())

#povprečno število smrti na dan po letih
povprecje_leta = list()
for leto in sl_leto_smrt:
    smrti = sl_leto_smrt[leto]
    dni = 0
    for el in podatki:
        if leto == el["year"]:
            dni += 1
    povprecje_leta.append((leto, int(smrti/dni)))

#povprečje smrti na dan v Evropi
povprecje_smrti = int(vse_smrti/len(podatki))

#primerjava smrti v enem mescu glede na leto
#leta = [2020, 2021, 2022]
sl_mesec = {}
for el in podatki:
    if int(el['month']) in sl_mesec.keys():
        if el["deaths"] != None:
            sl_mesec[int(el['month'])][el["year"]]  += el["deaths"]
    else:
        leta = {2020: 0, 2021: 0, 2022: 0}
        if el["deaths"] != None:
            leta[el["year"]] = el["deaths"]
        sl_mesec[int(el['month'])] = leta

#primerjava smrti v eni državi glede na leto
sl_drzava = {}
for el in podatki:
    if el['countriesAndTerritories'] in sl_drzava.keys():
        if el["deaths"] != None:
            sl_drzava[el['countriesAndTerritories']][el["year"]]  += el["deaths"]
    else:
        leta = {2020: 0, 2021: 0, 2022: 0}
        if el["deaths"] != None:
            leta[el["year"]] = el["deaths"]
        sl_drzava[el['countriesAndTerritories']] = leta


#Začetek programa
print('Pozdravljeni!\n' +
      'V tem programu so predstavljene različne analize podatkov o številu umrlih zaradi COVID-19 v Evropi od leta 2020.\n' +
      '1: Skupno število umrlih do sedaj in povprečno število umrlih v enem dnevu za vsako državo\n' +
      '2: Skupno število umrlih do sedaj in povprečno število umrlih v enem dnevu v Evropi za vsako leto\n'+
      '3: Skupno število umrlih v Evropi do sedaj in povprečno število umrli na dan\n' +
      '4: Primerjava števila umrlih v enem mescu glede na leto\n' +
      '5: Primerjava števila umrlih v eni državi glede na leto\n' +
      'Vpišite številko analize, ki vas zanima')
st = int(input('Kaj vas zanima? Št. '))

if st == 1:
    print('Seznam držav in število smrti:', sl_drzave_smrt)
    print('Urejen seznam držav in število smrti od največ do najmanj: ', sorted(list_drzave_smrt, key = lambda x: x[1])[::-1])
    print('Povprečno število umrlih v enem dnevu za vsako državo: ', povprecje_drzav)
    #graf
    barve = ['purple','brown','teal']
    smrt_drzava = list(sl_drzave_smrt.items())
    x_d = [el[0] for el in smrt_drzava]
    y_d = [el[1] for el in smrt_drzava]
    fig, ax = plt.subplots(figsize =(16, 9))
    ax.barh(x_d, y_d, color=barve)
    plt.title('Število umrlih za vsako državo')
    plt.xlabel('Država')
    plt.ylabel('Število smrti')
    plt.show()
if st == 2:
    print('seznam letnic in število smrti:', sl_leto_smrt)
    print('Urejen seznam letnic in število smrti od največ do najmanj: ', sorted(list_leto_smrt, key = lambda x: x[1])[::-1])
    print('Povprečno število umrlih v enem dnevu za vsako leto: ', povprecje_leta)
    #graf
    smrt_leto = list(sl_leto_smrt.items())
    x_l = [str(el[0]) for el in smrt_leto]
    y_l = [el[1] for el in smrt_leto]
    trkizna = ['teal']
    plt.bar(x_l,y_l, color=trkizna)
    plt.xlabel('Leto')
    plt.ylabel('Število smrti')
    plt.show()
if st == 3:
    print('Število umrlih v Evropi: ', vse_smrti)
    print('Povprečno število umrlih na dan: ', povprecje_smrti)
if st == 4:
    print('Primerjava števila umrlih v enem mescu glede na leto: ', sl_mesec)
    #graf
    barWidth = 0.25
    fig = plt.subplots(figsize =(12, 8))
    l1 = []
    l2 = []
    l3 = []
    for i in range(1, 13):
        mesec = sl_mesec[i]
        l1.append(mesec[2020])
        l2.append(mesec[2021])
        l3.append(mesec[2022])
    br1 = np.arange(len(l1))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    plt.bar(br1, l1, color ='purple', width = barWidth,
        edgecolor ='grey', label ='2020')
    plt.bar(br2, l2, color ='brown', width = barWidth,
        edgecolor ='grey', label ='2021')
    plt.bar(br3, l3, color ='teal', width = barWidth,
        edgecolor ='grey', label ='2022')
    plt.xlabel('Mesec', fontweight ='bold', fontsize = 15)
    plt.ylabel('Smrti', fontweight ='bold', fontsize = 15)
    plt.xticks([r + barWidth for r in range(len(l1))],[i for i in range(1, 13)])
    plt.legend()
    plt.show()
if st == 5:
    print(sl_drzava)
    #graf
    barWidth = 0.25
    fig = plt.subplots(figsize =(12, 8))
    l1 = []
    l2 = []
    l3 = []
    for i in sl_drzava:
        drzava = sl_drzava[i]
        l1.append(drzava[2020])
        l2.append(drzava[2021])
        l3.append(drzava[2022])
    br1 = np.arange(len(l1))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    plt.bar(br1, l1, color ='purple', width = barWidth,
        edgecolor ='grey', label ='2020')
    plt.bar(br2, l2, color ='brown', width = barWidth,
        edgecolor ='grey', label ='2021')
    plt.bar(br3, l3, color ='teal', width = barWidth,
        edgecolor ='grey', label ='2022')
    plt.xlabel('Država', fontweight ='bold', fontsize = 15)
    plt.ylabel('Smrti', fontweight ='bold', fontsize = 15)
    plt.xticks([r + barWidth for r in range(len(l1))],sl_drzava.keys(), fontsize = 4)
    plt.legend()
    plt.show()
st2 = int(input('Ali vas zanima še kaj(če ste si ogledali vse kar vas je zanimalo pritisnite 0)? Št. '))
while st2 != 0:
    if st2 == 1:
        print(sl_drzave_smrt)
        print('Urejen seznam držav in število smrti od največ do najmanj: ', sorted(list_drzave_smrt, key = lambda x: x[1])[::-1])
        print('Povprečno število umrlih v enem dnevu za vsako državo: ', povprecje_drzav)
        #graf
        barve = ['purple','brown','teal']
        smrt_drzava = list(sl_drzave_smrt.items())
        x_d = [el[0] for el in smrt_drzava]
        y_d = [el[1] for el in smrt_drzava]
        fig, ax = plt.subplots(figsize =(16, 9))
        ax.barh(x_d, y_d, color=barve)
        plt.title('Število umrlih za vsako državo')
        plt.xlabel('Država')
        plt.ylabel('Število smrti')
        plt.show()
    if st2 == 2:
        print(sl_leto_smrt)
        print(sorted(list_leto_smrt, key = lambda x: x[1])[::-1])
        print(povprecje_leta)
        #graf
        smrt_leto = list(sl_leto_smrt.items())
        x_l = [str(el[0]) for el in smrt_leto]
        y_l = [el[1] for el in smrt_leto]
        trkizna = ['teal']
        plt.bar(x_l,y_l, color=trkizna)
        plt.xlabel('Leto')
        plt.ylabel('Število smrti')
        plt.show()
    if st2 == 3:
       print(vse_smrti)
       print(povprecje_smrti)
    if st2 == 4:
        print(sl_mesec)
        #graf
        barWidth = 0.25
        fig = plt.subplots(figsize =(12, 8))
        l1 = []
        l2 = []
        l3 = []
        for i in range(1, 13):
            mesec = sl_mesec[i]
            l1.append(mesec[2020])
            l2.append(mesec[2021])
            l3.append(mesec[2022])
        br1 = np.arange(len(l1))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        plt.bar(br1, l1, color ='purple', width = barWidth, edgecolor ='grey', label ='2020')
        plt.bar(br2, l2, color ='brown', width = barWidth, edgecolor ='grey', label ='2021')
        plt.bar(br3, l3, color ='teal', width = barWidth, edgecolor ='grey', label ='2022')
        plt.xlabel('Mesec', fontweight ='bold', fontsize = 15)
        plt.ylabel('Smrti', fontweight ='bold', fontsize = 15)
        plt.xticks([r + barWidth for r in range(len(l1))],[i for i in range(1, 13)])
        plt.legend()
        plt.show()
    if st2 == 5:
        print('Primerjava števila umrlih v eni državi glede na leto: ', sl_drzava)
        #graf
        barWidth = 0.25
        fig = plt.subplots(figsize =(12, 8))
        l1 = []
        l2 = []
        l3 = []
        for i in sl_drzava:
            drzava = sl_drzava[i]
            l1.append(drzava[2020])
            l2.append(drzava[2021])
            l3.append(drzava[2022])
        br1 = np.arange(len(l1))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        plt.bar(br1, l1, color ='purple', width = barWidth, edgecolor ='grey', label ='2020')
        plt.bar(br2, l2, color ='brown', width = barWidth, edgecolor ='grey', label ='2021')
        plt.bar(br3, l3, color ='teal', width = barWidth, edgecolor ='grey', label ='2022')
        plt.xlabel('Država', fontweight ='bold', fontsize = 15)
        plt.ylabel('Smrti', fontweight ='bold', fontsize = 15)
        plt.xticks([r + barWidth for r in range(len(l1))],sl_drzava.keys(), fontsize = 4)
        plt.legend()
        plt.show()
    st2 = int(input('Ali vas zanima še kaj(če ste si ogledali vse kar vas je zanimalo pritisnite 0)? Št. '))
print('Nasvidenje!')
f.close()
